﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;

namespace Yad_Aloun2.Controllers
{
    public class CompanyController : Controller
    {
        private readonly AppDbContext _DB;
        public CompanyController(AppDbContext DB)
        {
            _DB = DB;
        }

        public async Task<IActionResult> Index()
        {
            var data = await _DB.Donor_Company.ToListAsync();

            return View(data);
        }
        [HttpGet]
        public IActionResult Login()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Login(Donor_Company company)
        {
            if (ModelState.IsValid)
            {
                _DB.Donor_Company.Add(company);
                await _DB.SaveChangesAsync();

                HttpContext.Session.SetString("Role", "Company");
                HttpContext.Session.SetInt32("CompanyId", company.Company_ID);

                return RedirectToAction("HomeCompany");
            }

            return View(company);
        }
        [HttpGet]
        public IActionResult HomeCompany()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Company")
            {
                return RedirectToAction("Index", "Home");
            }

            int? companyId = HttpContext.Session.GetInt32("CompanyId");

            if (companyId == null)
            {
                return RedirectToAction("Login");
            }

            var company = _DB.Donor_Company.Find(companyId);

            if (company == null)
            {
                return RedirectToAction("Login");
            }

            return View(company);
        }
        public IActionResult Statistics()
        {
            return View();
        }
        public IActionResult ManageServices()
        {
            var services = _DB.Center.ToList();

            return View(services);
        }
        public IActionResult CreateService()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateService(Center center)
        {
            center.CompanyId = HttpContext.Session.GetInt32("CompanyId");

            _DB.Center.Add(center);
            _DB.SaveChanges();

            return RedirectToAction("ManageServices");
        }
        public IActionResult Usage()
        {
            var data = _DB.usaglog.ToList();

            return View(data);
        }
        public IActionResult Profile()
        {
            int? companyId = HttpContext.Session.GetInt32("CompanyId");

            var company = _DB.Donor_Company
                             .FirstOrDefault(x => x.Company_ID == companyId);

            return View(company);
        }
        [HttpGet]
        public async Task<IActionResult> RequestAssistance()
        {
            var requests = await _DB.AssistanceRequest
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync();

            return View(requests);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RequestAssistance(AssistanceRequest model, IFormFile? file)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
                return RedirectToAction("Login", "User");

            model.UserId = userId.Value;
            model.CreatedAt = DateTime.Now;
            model.Status = "Pending";

            // إزالة الحقول التي تسبب مشاكل validation
            ModelState.Remove("AttachmentUrl");
            ModelState.Remove("UserId");
            ModelState.Remove("Status");
            ModelState.Remove("CreatedAt");

            if (!ModelState.IsValid)
                return View(model);

            // رفع الملف (إن وجد)
            if (file != null && file.Length > 0)
            {
                string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                Directory.CreateDirectory(uploadsFolder);

                string fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                model.AttachmentUrl = "/uploads/" + fileName;
            }
            else
            {
                model.AttachmentUrl = null;
            }

            try
            {
                _DB.AssistanceRequest.Add(model);
                await _DB.SaveChangesAsync();

                TempData["SuccessMessage"] = "تم إرسال الطلب بنجاح";

                // ⚠️ مهم: يرجع لصفحة الطلبات (المستخدم)
                return RedirectToAction("MyRequests", "Services");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }
     



    }
}
