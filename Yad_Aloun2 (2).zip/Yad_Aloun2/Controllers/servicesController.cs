﻿using Microsoft.AspNetCore.Http; // ضروري لقراءة السيشن
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Yad_Aloun2;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;          // تأكدي أن هذا اسم النيم-سبيس الصحيح لموديلاتك

namespace Yad_Aloun2.Controllers
{
    public class services : Controller
    {
        // 1. تهيئة قاعدة البيانات داخل الكنترولر
        private readonly AppDbContext _DB;
        public services(AppDbContext DB)
        {
            _DB = DB;
        }

        // 2. الصفحة الرئيسية للخدمات
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ReadMore()
        {
            return View();
        }

        // 3. صفحة طلب المساعدة (GET) -> تضعين الكود هنا

        [HttpGet]
        public IActionResult RequestAssistance()
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "User");
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RequestAssistance(
    AssistanceRequest model,
    IFormFile file)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "User");
            }

            model.UserId = userId.Value;

            if (file != null && file.Length > 0)
            {
                string uploadsFolder = Path.Combine(
                    Directory.GetCurrentDirectory(),
                    "wwwroot/uploads");

                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string fileName =
                    Guid.NewGuid().ToString() +
                    Path.GetExtension(file.FileName);

                string filePath =
                    Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                model.AttachmentUrl = "/uploads/" + fileName;
            }

            model.CreatedAt = DateTime.Now;
            model.Status = "Pending";

            _DB.AssistanceRequest.Add(model);
            await _DB.SaveChangesAsync();

            TempData["SuccessMessage"] = "تم إرسال الطلب بنجاح";

            return RedirectToAction("RequestAssistance");
        }

        // بقية صفحات الأكشن الخاصة بكِ...
        public IActionResult jobs()

        { 
            return View();
        }
        public IActionResult ServerMap() 
        { 
            return View();
        }

        public async Task<IActionResult> ReviewOrders()
        {
            int? uid = HttpContext.Session.GetInt32("UserId");

            if (uid == null)
            {
                return RedirectToAction("Login", "User");
            }

            var myRequests = await _DB.AssistanceRequest
                .Where(r => r.UserId == uid.Value)
                .ToListAsync();

            var myInquiries = await _DB.Inquiry
                .ToListAsync();

            ViewBag.Inquiries = myInquiries;

            return View(myRequests);
        }
        public IActionResult FamilySupport()
        { return View();
        }

        public IActionResult Support() 
        { return View();
        }
        [HttpPost]
        public async Task<IActionResult> SendInquiry(Inquiry inquiry)
        {
            inquiry.AdminReply = "";

            _DB.Inquiry.Add(inquiry);
            await _DB.SaveChangesAsync();

            TempData["Success"] = "تم إرسال استفسارك بنجاح!";
            return RedirectToAction("Support");
        }
        public IActionResult HelpRequsets() { return View(); }

        // أضيفي هذا الأكشن بدلاً من HomeProjects البسيط
        public IActionResult HomeProjects()
        {
            // الصفحة تفتح للجميع بدون تحقق
            // ViewBag لتمرير بيانات المستخدم إن كان مسجلاً
            int? userId = HttpContext.Session.GetInt32("UserId");
            if (userId != null)
            {
                var currentUser = _DB.Users.FirstOrDefault(u => u.User_Id == userId);
                if (currentUser != null)
                {
                    ViewBag.UserFullName = currentUser.FullName;
                    ViewBag.UserPhone = currentUser.Phone;
                    ViewBag.IsLoggedIn = true;
                }
            }
            else
            {
                ViewBag.IsLoggedIn = false;
            }
            return View();
        }

        // أكشن جديد: يتحقق هل المستخدم مسجل أم لا عند الضغط على الزر
        [HttpGet]
        public IActionResult CheckLogin()
        {
            int? userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                // إذا لم يسجل → نرجع JSON يطلب التحويل
                return Json(new { loggedIn = false });
            }
            var user = _DB.Users.FirstOrDefault(u => u.User_Id == userId);
            return Json(new
            {
                loggedIn = true,
                fullName = user?.FullName,
                phone = user?.Phone
            });
        }
    }
}