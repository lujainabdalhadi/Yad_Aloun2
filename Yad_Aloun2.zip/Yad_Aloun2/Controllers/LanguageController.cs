﻿using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;

namespace Yad_Aloun2.Areas.Admin.Controllers
{
    public class LanguageController : Controller
    {
        public IActionResult Change_Language(string culture, string returnUrl)
        {
          Response.Cookies.Append(
              CookieRequestCultureProvider.DefaultCookieName,
              CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
              new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1) }
          );
          return LocalRedirect(returnUrl ?? "/");
        }
    }
}
