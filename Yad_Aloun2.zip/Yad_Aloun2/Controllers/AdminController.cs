﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;

namespace Yad_Aloun2.Controllers
{
    public class AdminController : Controller
    {
        private readonly AppDbContext _DB;
        public AdminController(AppDbContext DB)
        {
            _DB = DB;
        }
        public async Task<IActionResult> Index()
        {
            var data = await _DB.Admins.Include(a => a.Inquiries).ToListAsync();

            return View(data);
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(Admin admin)
        {
            if (_DB.Admins.Any())
            {
                ModelState.AddModelError("", "تم إنشاء حساب المسؤول مسبقاً");
                return View(admin);
            }

            if (ModelState.IsValid)
            {
                _DB.Add(admin);
                await _DB.SaveChangesAsync();

                HttpContext.Session.SetInt32("AdminId", admin.Admin_Id);
                HttpContext.Session.SetString("Role", "Admin");

                return RedirectToAction(nameof(HomeAdmin));
            }

            return View(admin);
        }





        public IActionResult HomeAdmin()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }

            int? adminId = HttpContext.Session.GetInt32("AdminId");

            if (adminId == null)
            {
                return RedirectToAction("Login");
            }

            var admin = _DB.Admins.Find(adminId);

            return View(admin);
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Index", "Home");
        }


        [HttpGet]
        public IActionResult Overview()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            return View();

        }
        [HttpGet]
        public async Task<IActionResult> CentersAndServicesManagement()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            var centers = await _DB.Center.ToListAsync();
            return View(centers);
        }
        public IActionResult Create()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        [HttpPost]
        
        public async Task<IActionResult> Create(Center center)
        {
            if (ModelState.IsValid)
            {
                int? adminId = HttpContext.Session.GetInt32("AdminId");

                center.Admin_Id = adminId.Value;

                _DB.Center.Add(center);
                await _DB.SaveChangesAsync();

                return RedirectToAction("CentersAndServicesManagement");
            }

            return View(center);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CentersAndServicesManagement(Center center)
        {
            _DB.Center.Add(center);
            await _DB.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var center = await _DB.Center.FindAsync(id);
            if (center == null)
            {
                return NotFound();
            }
            return View(center);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id)
        {
            var center = await _DB.Center.FindAsync(id);
            if (center == null)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                _DB.Update(center);
                await _DB.SaveChangesAsync();
                return RedirectToAction(nameof(CentersAndServicesManagement));
            }

            return View(center);
        }
        public async Task<IActionResult> Delete(int id)
        {
            var Center = await _DB.Center.FindAsync(id);
            if (Center == null)

            {
                return NotFound();
            }
            return View(Center);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var Center = await _DB.Center.FindAsync(id);
            if (Center != null)
            {
                _DB.Center.Remove(Center);
                await _DB.SaveChangesAsync();
            }

            return RedirectToAction(nameof(CentersAndServicesManagement));
        }




        [HttpGet]
        public IActionResult RequestsForAssistance()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            var assistanceRequests = _DB.Inquiry.ToList();
            return View(assistanceRequests);
        }
        [HttpGet]
        public async Task<IActionResult> CompanyFiles()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            var CompanyFiles = await _DB.Company_Files.ToListAsync();
            return View(CompanyFiles);
        }
        [HttpGet]
        public async Task<IActionResult> UserFiles()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            var userFiles = await _DB.UserFile.ToListAsync();
            return View(userFiles);
        }

        [HttpGet]
        public IActionResult add_newJob()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
    }
}