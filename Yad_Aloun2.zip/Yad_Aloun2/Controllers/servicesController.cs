﻿using Microsoft.AspNetCore.Mvc;

namespace Yad_Aloun2.Controllers
{
    public class servicesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // 2. صفحة الوظائف - jobs
        public IActionResult Jobs()
        {
            return View();
        }

        // 3. صفحة خريطة الخوادم - map of servers
        public IActionResult ServerMap()
        {
            return View();
        }

        // 4. صفحة طلب المساعدة - submitting a request for assistance
        // صفحة طلب المساعدة - متاح التصفح ولكن التقديم يتطلب تسجيل دخول
        [HttpGet]
        public IActionResult RequestAssistance()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "User")
            {
                return RedirectToAction("Login", "User");
            }
          
         
            return View();
        }

        // 5. صفحة مراجعة الطلبات - review my orders
        public IActionResult ReviewOrders()
        {
            return View();
        }

        // 6. صفحة الدعم النفسي للعائلات - psychological support for families
        public IActionResult FamilySupport()
        {
            return View();
        }

        // 7. صفحة المشاريع المنزلية - home projects
        public IActionResult HomeProjects()
        {
            string role = HttpContext.Session.GetString("Role");

            if (role != "User")
            {
                return RedirectToAction("Login", "User");
            }


            return View();
        }

           
        

        public IActionResult Support()
        {
            return View();
        }

        // استقبال الاستفسار من الفورم
        [HttpPost]
        public IActionResult SendSupport(string name, string email, string message)
        {
            // هنا تضع كود حفظ الاستفسار في قاعدة البيانات
            // ...
            TempData["Success"] = "تم إرسال استفسارك بنجاح!";
            return RedirectToAction("Support");
        }
        public IActionResult HelpRequsets()
        {
            return View();
        }


       

    }

}