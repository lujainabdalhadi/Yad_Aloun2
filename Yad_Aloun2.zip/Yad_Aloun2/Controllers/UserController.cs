﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;

namespace Yad_Aloun2.Controllers
{
    public class UserController : Controller
    {
        public readonly AppDbContext _DB;
        public UserController(AppDbContext DB)
        {
            _DB = DB;
        }
        public async Task<IActionResult> Index()
        {
            var data = await _DB.Users.ToListAsync();

            return View(data);
        }
        [HttpGet]
        public IActionResult Login()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(User user)
        {
            if (ModelState.IsValid)
            {
                _DB.Users.Add(user);
                await _DB.SaveChangesAsync();
                HttpContext.Session.SetInt32("UserId", user.User_Id);
                HttpContext.Session.SetString("Role", user.Role);
                return RedirectToAction(nameof(Login));

            }
            return View(user);
        }

    }
}
