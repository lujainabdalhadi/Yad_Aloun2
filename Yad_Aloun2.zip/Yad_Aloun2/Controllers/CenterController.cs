﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;

namespace Yad_Aloun2.Controllers
{
    public class CenterController : Controller
    {
        private readonly AppDbContext _Db;
        public CenterController(AppDbContext Db)
        {
            _Db = Db;
        }
        public async Task<IActionResult> Index()
        {
            var data = await _Db.JobOpportunity.Include(a => a.Company).ToListAsync();
            return View(data);
        }
        [HttpGet]
        public async Task<IActionResult> Center()
        {
            return View();
        }

        [HttpGet]
        public IActionResult JobDetails(int id)
        {
            var job = _Db.JobOpportunity.Include(j => j.Company).FirstOrDefault(j => j.Id == id);
            if (job == null)
            {
                return NotFound();
            }
            return View(job);
        }
    
    [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Center(JobOpportunity job)
        {
            if (ModelState.IsValid)
            {
                _Db.Add(job);
                await _Db.SaveChangesAsync();
                return RedirectToAction(nameof(Center));
            }
            return View(job);
        }
    }
}

      