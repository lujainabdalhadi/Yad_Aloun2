﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;

namespace Yad_Aloun2.Controllers
{
    public class AdminController : Controller
    {
        private readonly AppDbContext _DB;
        public AdminController(AppDbContext DB)
        {
            _DB = DB;
        }
        public async Task<IActionResult> Index()
        {
            var data = await _DB.Admins.Include(a => a.Inquiries).ToListAsync();

            return View(data);
        }
        [HttpGet]
        public IActionResult Login()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(Admin admin)
        {
            if (ModelState.IsValid)
            {
                _DB.Add(admin);
                await _DB.SaveChangesAsync();
                HttpContext.Session.SetInt32("AdminId", admin.Admin_Id);

                return RedirectToAction(nameof(HomeAdmin));

            }
            return View(admin);

        }


        [HttpGet]
        public IActionResult HomeAdmin()
        {
            var id = HttpContext.Session.GetInt32("AdminId");

            var admin = _DB.Admins.Find(id);

           
            return View(admin);

        }
        [HttpGet]
        public IActionResult Overview()
        {
            return View();

        }
        [HttpGet]
        public async Task<IActionResult> CentersAndServicesManagement()
        {
            var centers = await _DB.Center.ToListAsync();
            return View(centers);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CentersAndServicesManagement(Admin admin)
        {
            _DB.Admins.Add(admin);
            await _DB.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var center = await _DB.Center.FindAsync(id);
            if (center == null)
            {
                return NotFound();
            }
            return View(center);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id)
        {
            var center = await _DB.Center.FindAsync(id);
            if (center == null)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                _DB.Update(center);
                await _DB.SaveChangesAsync();
                return RedirectToAction(nameof(CentersAndServicesManagement));
            }

            return View(center);
        }
        public async Task<IActionResult> Delete(int id)
        {
            var Center = await _DB.Center.FindAsync(id);
            if (Center == null)

            {
                return NotFound();
            }
            return View(Center);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var Center = await _DB.Center.FindAsync(id);
            if (Center != null)
            {
                _DB.Center.Remove(Center);
                await _DB.SaveChangesAsync();
            }

            return RedirectToAction(nameof(CentersAndServicesManagement));
        }




        [HttpGet]
        public IActionResult RequestsForAssistance()
        {
            var assistanceRequests = _DB.Inquiry.ToList();
            return View(assistanceRequests);    
        }
        [HttpGet]
        public async Task<IActionResult> CompanyFiles()
        {
            var CompanyFiles = await _DB.Company_Files.ToListAsync();
            return View(CompanyFiles);
        }
        [HttpGet]
        public async Task<IActionResult> UserFiles()
        {
            var userFiles = await _DB.UserFile.ToListAsync();
            return View(userFiles);
        }
    }
}