﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yad_Aloun2.Data;
using Yad_Aloun2.Models;

namespace Yad_Aloun2.Controllers
{
    public class CompanyController : Controller
    {
        private readonly AppDbContext _DB;
        public CompanyController(AppDbContext DB)
        {
            _DB = DB;
        }

        public async Task<IActionResult> Index()
        {
            var data = await _DB.Donor_Company.ToListAsync();

            return View(data);
        }
        [HttpGet]
        public IActionResult Login()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(Donor_Company company)
        {
            if (ModelState.IsValid)
            {
                _DB.Donor_Company.Add(company);
                await _DB.SaveChangesAsync();
                return RedirectToAction(nameof(Login));
            }
            return View(company);
        }
    }
    }
