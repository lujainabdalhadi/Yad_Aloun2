﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Yad_Aloun2.Models
{
    public class Admin
    {
        [Key]
        public int Admin_Id { get; set; }
        [Required (ErrorMessage ="Please Enter Your Name")]
        public string AdminName { get; set; }
        [Required]
        public int Age { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [Phone]
        public string PhoneNumber { get; set; }
        [Required]
        public string Certificates_Path { get; set; }
        [Required]
        public string Location { get; set; }
        [Required]
        public string AdminPassword { get; set; }
        [NotMapped]
        [Compare("AdminPassword", ErrorMessage = "Passwords do not match.")]
        public string ConfirmPassword { get; set; }

        [Required]
        public string CV_Path { get; set; }
        [Required]
        public string ProfileImagePath { get; set; }
        [ValidateNever]

        public ICollection<Inquiry> Inquiries { get; set; }
        [ValidateNever]

        public ICollection<Center> Center { get; set; }
       

    }


}

